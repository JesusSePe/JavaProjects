Arxiu principal -> login.java
Accedir al panell d'administració: Al login, user: admin, password: admin