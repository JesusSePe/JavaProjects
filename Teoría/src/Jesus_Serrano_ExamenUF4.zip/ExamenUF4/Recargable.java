package ExamenUF4;

public interface Recargable {
    // Methods
    public void recargarBateria();
}
